# SGCC-2018
Bunch of students try building a game
